import { LevelWithUserDB } from './../../src/types/database-aliases';
export type OnlineLevelsFixture = {
	count: number;
	data: LevelWithUserDB[];
};
