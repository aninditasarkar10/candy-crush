export default {
	'Red': '#ff2445',
	'Orange': '#ff670f',
	'Yellow': '#ffbf0f',
	'Green': '#16f74f',
	'Blue': '#1670f7',
	'Purple': '#7b16f7',
	'White': '#fff',
} as { [key: string]: string };
