import DeleteAccountDialog from './DeleteAccountDialog';
export default DeleteAccountDialog;
