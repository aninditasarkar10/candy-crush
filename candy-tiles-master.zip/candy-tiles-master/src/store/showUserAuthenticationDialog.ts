import { atom } from 'recoil';

export const showUserAuthDialogState = atom({
	key: 'showUserAuthDialog',
	default: false,
});
