import LevelEditorPage from './LevelEditorPage';

export default LevelEditorPage;
