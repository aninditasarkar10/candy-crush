import CandyTiles from './CandyTiles';

export default CandyTiles;
