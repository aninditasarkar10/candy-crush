import GameDialogs from './GameDialogs';
export default GameDialogs;
