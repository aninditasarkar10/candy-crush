import GameOverDialog from './GameOverDialog';
export default GameOverDialog;
