import LeftPanel from './LeftPanel';
export default LeftPanel;
