import LevelProgressPanel from './LevelProgressPanel';

export default LevelProgressPanel;
