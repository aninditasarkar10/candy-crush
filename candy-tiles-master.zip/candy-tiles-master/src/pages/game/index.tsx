import GamePage from './GamePage';

export default GamePage;
