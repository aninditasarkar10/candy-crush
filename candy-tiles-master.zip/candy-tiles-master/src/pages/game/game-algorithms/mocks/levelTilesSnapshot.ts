import { LevelTile } from './../../candy-tiles/types/index';
export default [
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	null,
	null,
	null,
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Normal',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Ice',
	},
	{
		'type': 'Ice',
	},
	{
		'type': 'Ice',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Rock',
	},
	{
		'type': 'Rock',
	},
] as LevelTile[];
