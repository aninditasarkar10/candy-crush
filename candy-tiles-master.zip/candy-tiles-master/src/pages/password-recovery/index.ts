import PasswordRecoveryPage from './PasswordRecoveryPage';
export default PasswordRecoveryPage;
