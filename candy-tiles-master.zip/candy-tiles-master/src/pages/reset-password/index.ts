import ResetPasswordPage from './ResetPasswordPage';
export default ResetPasswordPage;
